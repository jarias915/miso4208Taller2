var TR = require("./testrec.helpers.js");

describe('Suite 1', function () {
    beforeEach(function() {
        TR.closeTabs();
        browser.driver.manage().window().setPosition(0, 0);
        browser.driver.manage().window().setSize(1200, 900);
        browser.get('http://localhost:4200/dashboard/');
    });

    it('Scenario 1', function () {
        element(by.css("html > body > my-app > nav > a:nth-of-type(2)")).click();
        element(by.css("html > body > my-app > my-heroes > ul > li:nth-of-type(1) > span:nth-of-type(2)")).click();
        element(by.css("html > body > my-app > my-heroes > div:nth-of-type(2) > button")).click();
        element(by.css("html > body > my-app > hero-detail > div > div:nth-of-type(2) > input")).click();
        element(by.css("html > body > my-app > hero-detail > div > div:nth-of-type(2) > input")).sendKeys('1');
        element(by.css("html > body > my-app > hero-detail > div > div:nth-of-type(2) > input")).sendKeys('23');
        element(by.css("html > body > my-app > hero-detail > div > button:nth-of-type(2)")).click();
        expect(element(by.css("html > body > my-app > my-heroes")).getText()).toContain('Zero123');
    });
});

var TR = require("./testrec.helpers.js");

describe('Suite 1', function () {
    beforeEach(function() {
        TR.closeTabs();
        browser.driver.manage().window().setPosition(0, 0);
        browser.driver.manage().window().setSize(1000, 900);
        browser.get('http://localhost:4200/dashboard/');
    });

    it('Scenario 1', function () {
        element(by.css("html > body > my-app > nav > a:nth-of-type(2)")).click();
        element(by.css("html > body > my-app > my-heroes > ul > li:nth-of-type(1) > button")).click();
        expect(element(by.css("html > body > my-app > my-heroes")).getText()).not.toContain('Zero');
    });
});

var TR = require("./testrec.helpers.js");

describe('Suite 1', function () {
    beforeEach(function() {
        TR.closeTabs();
        browser.driver.manage().window().setPosition(0, 0);
        browser.driver.manage().window().setSize(1200, 900);
        browser.get('http://localhost:4200/dashboard/');
    });

    it('Scenario 1', function () {
        element(by.css("*[id='search-box']")).click();
        element(by.css("*[id='search-box']")).sendKeys('as');
        element(by.css("*[id='search-component'] > div > div:nth-of-type(1)")).click();
        expect(element(by.css("html > body > my-app > hero-detail > div > h2")).getText()).toBe('Bombasto details!');
    });
});

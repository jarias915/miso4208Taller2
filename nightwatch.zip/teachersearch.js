
module.exports = {
 'test case': function(client) {
   return client
     .resizeWindow(1920, 974)
     .url('https://losestudiantes.co/')
     .waitForElementVisible(".botones .botonCerrar.btn.btn-default", 2000)
     .customClick(".botones .botonCerrar.btn.btn-default")
     .waitForElementVisible("input", 2000)
     .setValue("input", "dario correal")
     .expect.element("title").text.to.equal(\'Dario Correal | Los Estudiantes\')

 }
};
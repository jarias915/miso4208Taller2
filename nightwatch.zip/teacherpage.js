
module.exports = {
 'test case': function(client) {
   return client
     .resizeWindow(1920, 974)
     .url('https://losestudiantes.co/')
     .waitForElementVisible(".botones .botonCerrar.btn.btn-default", 2000)
     .customClick(".botones .botonCerrar.btn.btn-default")
     .waitForElementVisible(".altura.col-md-2:nth-child(3) a > div", 2000)
     .customClick(".altura.col-md-2:nth-child(3) a > div")
     .expect.element("title").text.to.equal(\'Kelly Johany Garces Pernett | Los Estudiantes\')

 }
};
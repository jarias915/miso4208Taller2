module.exports = {
 'test case': function(client) {
   return client
     .resizeWindow(1920, 974)
     .url('https://losestudiantes.co/')
     .waitForElementVisible(".botones .botonCerrar.btn.btn-default", 2000)
     .customClick(".botones .botonCerrar.btn.btn-default")
     .waitForElementVisible(".altura.col-md-2:nth-child(2) a > div", 2000)
     .customClick(".altura.col-md-2:nth-child(2) a > div")
     .waitForElementVisible("form input[name='ISIS2603']", 2000)
     .customClick("form input[name='ISIS2603']")
     .expect.element("title").text.to.equal(\'Rubby Casallas Gutierrez | Los Estudiantes\')

 }
};
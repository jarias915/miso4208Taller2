
module.exports = {
 'test case': function(client) {
   return client
     .resizeWindow(1920, 974)
     .url('https://losestudiantes.co/')
     .waitForElementVisible(".botones .botonCerrar.btn.btn-default", 2000)
     .customClick(".botones .botonCerrar.btn.btn-default")
     .waitForElementVisible(".botonIngresar.btn.btn-primary", 2000)
     .customClick(".botonIngresar.btn.btn-primary")
     .waitForElementVisible("form input[name='nombre']", 2000)
     .customClick("form input[name='nombre']")
     .waitForElementVisible("input[name='nombre']", 2000)
     .setValue("input[name='nombre']", "carlos")
     .waitForElementVisible("form input[name='apellido']", 2000)
     .customClick("form input[name='apellido']")
     .waitForElementVisible("input[name='apellido']", 2000)
     .setValue("input[name='apellido']", "ramirez")
     .waitForElementVisible("form input[name='correo']", 2000)
     .customClick("form input[name='correo']")
     .waitForElementVisible("input[name='correo']", 2000)
     .setValue("input[name='correo']", "j,..arias915@uniandes.edu.co")
     .waitForElementVisible(".cajaSignUp fieldset:nth-child(4) select", 2000)
     .customClick(".cajaSignUp fieldset:nth-child(4) select")
     .waitForElementVisible(".cajaSignUp fieldset:nth-child(5) select", 2000)
     .customClick(".cajaSignUp fieldset:nth-child(5) select")
     .waitForElementVisible("form input[name='password']", 2000)
     .customClick("form input[name='password']")
     .waitForElementVisible("input[name='password']", 2000)
     .setValue("input[name='password']", "password")
     .waitForElementVisible("form input[name='acepta']", 2000)
     .customClick("form input[name='acepta']")
     .waitForElementVisible("form .cajaSignUp .logInButton.fullWidth.btn.btn-primary", 2000)
     .customClick("form .cajaSignUp .logInButton.fullWidth.btn.btn-primary")
 /* submit form */
     .expect.element("title").text.to.equal(\'Los Estudiantes | Empoderamiento Estudiantil\')

 }
};
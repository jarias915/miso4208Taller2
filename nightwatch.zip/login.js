
module.exports = {
 'test case': function(client) {
   return client
     .resizeWindow(1920, 974)
     .url('https://losestudiantes.co/')
     .waitForElementVisible(".botones .botonCerrar.btn.btn-default", 2000)
     .customClick(".botones .botonCerrar.btn.btn-default")
     .waitForElementVisible(".botonIngresar.btn.btn-primary", 2000)
     .customClick(".botonIngresar.btn.btn-primary")
     .waitForElementVisible("form input[name='correo']", 2000)
     .customClick("form input[name='correo']")
     .waitForElementVisible("input[name='correo']", 2000)
     .setValue("input[name='correo']", "j.arias915@uniandes.edu.co")
     .waitForElementVisible("form input[name='password']", 2000)
     .customClick("form input[name='password']")
     .waitForElementVisible("input[name='password']", 2000)
     .setValue("input[name='password']", "j2017cext")
     .waitForElementVisible("form .cajaLogIn .logInButton.fullWidth.btn.btn-primary", 2000)
     .customClick("form .cajaLogIn .logInButton.fullWidth.btn.btn-primary")
 /* submit form */
     .expect.element("title").text.to.equal(\'Los Estudiantes | Empoderamiento Estudiantil\')

 }
};